/** @type {import('next').NextConfig} */
const nextConfig = {
  // Standard Node.js deployment configuration
};

module.exports = nextConfig;
