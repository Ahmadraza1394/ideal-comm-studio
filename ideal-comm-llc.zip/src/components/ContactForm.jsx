'use client';

import { motion } from 'framer-motion';
import { staggerContainer, fadeUpVariant } from '@/lib/motion';

export default function ContactForm() {
  return (
    <section id="contact" className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={fadeUpVariant}
          >
            <h2 className="font-serif italic text-5xl md:text-6xl mb-6">
              Let&apos;s Create Something Amazing
            </h2>
            <p className="font-sans text-gray-600 text-lg leading-relaxed">
              Ready to elevate your brand? Get in touch and let&apos;s discuss how we can bring your vision to life.
            </p>
          </motion.div>

          <motion.form
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            className="space-y-6"
          >
            <motion.div variants={fadeUpVariant}>
              <input
                type="text"
                placeholder="Name"
                className="w-full border border-black px-4 py-3 focus:border-brand-pink outline-none transition-colors font-sans"
              />
            </motion.div>

            <motion.div variants={fadeUpVariant}>
              <input
                type="email"
                placeholder="Email"
                className="w-full border border-black px-4 py-3 focus:border-brand-pink outline-none transition-colors font-sans"
              />
            </motion.div>

            <motion.div variants={fadeUpVariant}>
              <select
                className="w-full border border-black px-4 py-3 focus:border-brand-pink outline-none transition-colors font-sans bg-white"
              >
                <option>Project Type</option>
                <option>Brand Identity</option>
                <option>Digital Design</option>
                <option>Creative Direction</option>
                <option>Content Strategy</option>
              </select>
            </motion.div>

            <motion.div variants={fadeUpVariant}>
              <textarea
                placeholder="Tell us about your project"
                rows="6"
                className="w-full border border-black px-4 py-3 focus:border-brand-pink outline-none transition-colors font-sans resize-none"
              />
            </motion.div>

            <motion.div variants={fadeUpVariant}>
              <button
                type="submit"
                className="w-full bg-brand-pink text-white px-8 py-4 rounded-lg hover:bg-opacity-90 transition-all font-sans flex items-center justify-center gap-2"
              >
                Send Message
                <span>→</span>
              </button>
            </motion.div>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
